import Pokedex from 'pokedex-promise-v2';
import {readFileSync, writeFileSync} from 'fs';
const p = new Pokedex();

const wanted = []

readFileSync('my-pokemon.txt').toString().split('\n').forEach(entry => wanted.push(entry.trim().toLowerCase()))

const pokemons = await p.getPokemonsList().then(pokemon => pokemon.results.filter(pokemon => wanted.includes(pokemon.name)))

const out = []

console.log("Filtering done")

const capitalize = (input) => {
    return input[0].toUpperCase() + input.substring(1).toLowerCase();
}

const process = async (pokemon) => {
    try {
        const obj = {
            name: capitalize(pokemon.name),
            frontSprite: 'f_' + pokemon.name,
            backSprite: 'b_' + pokemon.name,
        }
        const data = await p.getPokemonByName(pokemon.name)
        const species = await p.getPokemonSpeciesByName(data.species.name)
        obj['cr'] = species.capture_rate
        obj["type"] = capitalize(data.types[0].type.name)
        obj["type2"] = data.types.length > 1 ? capitalize(data.types[1].type.name) : "None"
        data.stats.forEach(stat => {
            switch (stat.stat.name) {
                case 'hp':
                    obj["hp"] = stat.base_stat
                    break
                case 'attack':
                    obj["atk"] = stat.base_stat
                    break
                case 'defense':
                    obj["def"] = stat.base_stat
                    break
                case 'special-attack':
                    obj["spat"] = stat.base_stat
                    break
                case 'special-defense':
                    obj["spdef"] = stat.base_stat
                    break
                case 'speed':
                    obj["speed"] = stat.base_stat
                    break
            }
        })
        obj["moves"] = []
        data.moves.forEach(move => {
            move.version_group_details.forEach(detail => {
                if (detail.move_learn_method.name === 'level-up' && detail.version_group.name === 'emerald')
                    obj['moves'].push({
                        name: move.move.name,
                        levelLearned: detail.level_learned_at
                    })
            })
        })
        out.push(obj)
        console.log("Processed " + capitalize(pokemon.name))
    } catch (e) {
        console.log(e)
    }
}

for (let i = 0; i < pokemons.length; i++)
    await process(pokemons[i])

console.log("Writing output")

writeFileSync('out.json', JSON.stringify(out))

console.log("Done")